import * as THREE from "three";

console.info("AITS_V63_BOOT — Three.js scene + cinematic controller");
const mount=document.getElementById("scene");
const scene=new THREE.Scene();
scene.fog=new THREE.FogExp2(0x02060b,.014);
const camera=new THREE.PerspectiveCamera(40,innerWidth/innerHeight,.1,1000);
camera.position.set(0,7.8,27);

const renderer=new THREE.WebGLRenderer({antialias:true,alpha:true});
renderer.setPixelRatio(Math.min(devicePixelRatio,1.7));
renderer.setSize(innerWidth,innerHeight);
renderer.outputColorSpace=THREE.SRGBColorSpace;
mount.appendChild(renderer.domElement);

scene.add(new THREE.HemisphereLight(0x8cc9ff,0x02050a,1.35));
const key=new THREE.DirectionalLight(0xb8f4ff,2.5);key.position.set(10,18,12);scene.add(key);
const blue=new THREE.PointLight(0x0057ff,9,35);blue.position.set(8,9,2);scene.add(blue);

// Ground and terrain
const terrainGeo=new THREE.PlaneGeometry(40,25,48,34);
const pos=terrainGeo.attributes.position;
for(let i=0;i<pos.count;i++){const x=pos.getX(i),z=pos.getZ(i);pos.setY(i,(Math.sin(x*.43)+Math.cos(z*.57)+Math.sin((x-z)*.28))*.16)}
terrainGeo.computeVertexNormals();
const terrain=new THREE.Mesh(terrainGeo,new THREE.MeshStandardMaterial({color:0x071a2d,metalness:.48,roughness:.5,emissive:0x00152b,emissiveIntensity:.55}));
terrain.rotation.x=-Math.PI/2;terrain.position.y=-.35;scene.add(terrain);
const grid=new THREE.GridHelper(44,36,0x0057ff,0x07365c);grid.material.transparent=true;grid.material.opacity=.2;grid.position.y=-.14;scene.add(grid);

// Smart city
const city=new THREE.Group();scene.add(city);
const buildingMat=new THREE.MeshStandardMaterial({color:0x0a2037,metalness:.72,roughness:.25,emissive:0x001a36,emissiveIntensity:.65});
for(let x=-13;x<=13;x+=1.25)for(let z=-7;z<=7;z+=1.25){
  if(Math.random()>.57)continue;
  const h=.65+Math.random()*6.1,w=.48+Math.random()*.75;
  const b=new THREE.Mesh(new THREE.BoxGeometry(w,h,w),buildingMat);
  b.position.set(x+(Math.random()-.5)*.3,h/2-.05,z+(Math.random()-.5)*.3);city.add(b);
  const e=new THREE.LineSegments(new THREE.EdgesGeometry(b.geometry),new THREE.LineBasicMaterial({color:0x007cff,transparent:true,opacity:.22}));
  e.position.copy(b.position);city.add(e);
}

// Detailed UAV
const drone=new THREE.Group();scene.add(drone); drone.scale.setScalar(1.38);
drone.position.set(6.6,8,3);
const dark=new THREE.MeshStandardMaterial({color:0x101b28,metalness:.92,roughness:.15});
const trim=new THREE.MeshStandardMaterial({color:0x17364d,metalness:.82,roughness:.2});
const glow=new THREE.MeshStandardMaterial({color:0x06394e,emissive:0x00d9ff,emissiveIntensity:1.5});
const body=new THREE.Mesh(new THREE.BoxGeometry(1.85,.38,.78),dark);drone.add(body);
const nose=new THREE.Mesh(new THREE.SphereGeometry(.48,20,14),dark);nose.scale.set(1.25,.65,.82);nose.position.z=.42;drone.add(nose);
const top=new THREE.Mesh(new THREE.BoxGeometry(.8,.16,.5),trim);top.position.y=.26;drone.add(top);
const rotors=[];
for(const sx of[-1,1])for(const sz of[-1,1]){
  const arm=new THREE.Mesh(new THREE.BoxGeometry(1.9,.1,.12),dark);arm.position.set(sx*.78,.02,sz*.38);drone.add(arm);
  const motor=new THREE.Mesh(new THREE.CylinderGeometry(.14,.14,.16,18),trim);motor.position.set(sx*1.45,.08,sz*.54);drone.add(motor);
  const rotor=new THREE.Group();rotor.position.set(sx*1.45,.18,sz*.54);
  for(let k=0;k<2;k++){const blade=new THREE.Mesh(new THREE.BoxGeometry(.72,.014,.035),new THREE.MeshBasicMaterial({color:0x7beeff,transparent:true,opacity:.42}));blade.rotation.y=k*Math.PI/2;rotor.add(blade)}
  drone.add(rotor);rotors.push(rotor);
  const led=new THREE.Mesh(new THREE.SphereGeometry(.045,9,8),glow);led.position.set(sx*1.48,.02,sz*.6);drone.add(led);
}
const cameraGimbal=new THREE.Group();cameraGimbal.position.set(0,-.27,.27);drone.add(cameraGimbal);
const lens=new THREE.Mesh(new THREE.SphereGeometry(.14,18,12),new THREE.MeshStandardMaterial({color:0x01050a,emissive:0x00d9ff,emissiveIntensity:2.3,metalness:.4,roughness:.08}));lens.position.z=.13;cameraGimbal.add(lens);

// Scan beam and scan footprint
const beam=new THREE.Mesh(new THREE.ConeGeometry(1.05,8.2,48,1,true),new THREE.MeshBasicMaterial({color:0x00d9ff,transparent:true,opacity:.13,side:THREE.DoubleSide,depthWrite:false}));beam.rotation.x=Math.PI;beam.position.set(0,-4.1,0);drone.add(beam);
const footprint=new THREE.Mesh(new THREE.PlaneGeometry(5.8,5.8,28,28),new THREE.MeshBasicMaterial({color:0x00d9ff,wireframe:true,transparent:true,opacity:.22}));footprint.rotation.x=-Math.PI/2;footprint.position.y=-.06;scene.add(footprint);

// Highlighted survey zone: the same urban area is reused across all pipeline stages.

// Persistent analysis target: one recognizable structure is transformed through
// Aerial Data -> GIS -> Photogrammetry -> 3D Model -> AI Analysis.
const targetBuilding = new THREE.Group();
scene.add(targetBuilding);
const targetMarker=new THREE.Group(); scene.add(targetMarker);
const targetFrame=new THREE.Group();
scene.add(targetFrame);
const targetFrameMat=new THREE.LineBasicMaterial({
  color:0x00d9ff, transparent:true, opacity:0
});
const framePts=[
  new THREE.Vector3(-1.75,0,-1.5), new THREE.Vector3(1.75,0,-1.5),
  new THREE.Vector3(1.75,0,1.5), new THREE.Vector3(-1.75,0,1.5),
  new THREE.Vector3(-1.75,4.7,-1.5), new THREE.Vector3(1.75,4.7,-1.5),
  new THREE.Vector3(1.75,4.7,1.5), new THREE.Vector3(-1.75,4.7,1.5)
];
const frameEdges=[[0,1],[1,2],[2,3],[3,0],[4,5],[5,6],[6,7],[7,4],[0,4],[1,5],[2,6],[3,7]];
frameEdges.forEach(([a,b])=>{
  targetFrame.add(new THREE.Line(
    new THREE.BufferGeometry().setFromPoints([framePts[a],framePts[b]]),
    targetFrameMat
  ));
});
const targetCore=new THREE.Mesh(
  new THREE.SphereGeometry(.11,16,16),
  new THREE.MeshBasicMaterial({color:0x00d9ff,transparent:true,opacity:0})
);
targetCore.position.y=2.35;
targetBuilding.add(targetCore);
const targetSweep=new THREE.Mesh(
  new THREE.PlaneGeometry(3.2,4.2),
  new THREE.MeshBasicMaterial({
    color:0x00d9ff,transparent:true,opacity:0,
    side:THREE.DoubleSide,blending:THREE.AdditiveBlending
  })
);
targetSweep.position.set(0,2.1,0);
targetBuilding.add(targetSweep);

const markerMat=new THREE.LineBasicMaterial({color:0x00d9ff,transparent:true,opacity:0});
const markerCorners=[[-1.55,-1.35],[1.55,-1.35],[1.55,1.35],[-1.55,1.35]];
for(const [x,z] of markerCorners){
  const sx=x<0?1:-1, sz=z<0?1:-1;
  targetMarker.add(new THREE.Line(
    new THREE.BufferGeometry().setFromPoints([
      new THREE.Vector3(x,0,z),new THREE.Vector3(x-sx*.42,0,z)
    ]),markerMat));
  targetMarker.add(new THREE.Line(
    new THREE.BufferGeometry().setFromPoints([
      new THREE.Vector3(x,0,z),new THREE.Vector3(x,0,z-sz*.42)
    ]),markerMat));
}


const targetGlowMat=new THREE.MeshBasicMaterial({color:0x00d9ff,transparent:true,opacity:0,blending:THREE.AdditiveBlending});
const targetGlow=new THREE.Mesh(new THREE.BoxGeometry(2.5,3.7,2.3),targetGlowMat);
targetGlow.position.y=1.85;targetBuilding.add(targetGlow);

const targetSolidMat = new THREE.MeshStandardMaterial({
  color:0x123653, metalness:.78, roughness:.28,
  emissive:0x00365a, emissiveIntensity:.8, transparent:true, opacity:.96
});
const targetMeshMat = new THREE.MeshBasicMaterial({
  color:0x00d9ff, wireframe:true, transparent:true, opacity:0
});
const targetBox = new THREE.Mesh(
  new THREE.BoxGeometry(2.2,3.4,2.0),
  targetSolidMat
);
targetBox.position.y=1.7;
targetBuilding.add(targetBox);

const targetEdges = new THREE.LineSegments(
  new THREE.EdgesGeometry(targetBox.geometry),
  new THREE.LineBasicMaterial({color:0x00d9ff,transparent:true,opacity:.35})
);
targetEdges.position.copy(targetBox.position);
targetBuilding.add(targetEdges);

const targetMesh = new THREE.Mesh(
  new THREE.BoxGeometry(2.2,3.4,2.0,12,18,12),
  targetMeshMat
);
targetMesh.position.y=1.7;
targetBuilding.add(targetMesh);

// AI detection frames on the same target.
const aiFrameMat = new THREE.LineBasicMaterial({color:0x00d9ff,transparent:true,opacity:0});
const aiFrameGeo = new THREE.EdgesGeometry(new THREE.BoxGeometry(2.55,3.75,2.35));
const aiFrame = new THREE.LineSegments(aiFrameGeo, aiFrameMat);
aiFrame.position.y=1.9;
targetBuilding.add(aiFrame);

// Small analysis points that pulse only in the AI phase.
const targetBase=new THREE.Mesh(
  new THREE.PlaneGeometry(3.6,3.2),
  new THREE.MeshBasicMaterial({color:0x00d9ff,transparent:true,opacity:0,wireframe:true})
);
targetBase.rotation.x=-Math.PI/2;targetBase.position.y=.03;targetBuilding.add(targetBase);

const detectionLines=new THREE.Group();
const detectionLineMat=new THREE.LineBasicMaterial({color:0xffffff,transparent:true,opacity:0});
for(let i=0;i<8;i++){
  const y=.45+i*.42;
  const geo=new THREE.BufferGeometry().setFromPoints([
    new THREE.Vector3(-1.05,y,-1.02),new THREE.Vector3(1.05,y,-1.02)
  ]);
  detectionLines.add(new THREE.Line(geo,detectionLineMat));
}
targetBuilding.add(detectionLines);


const analysisZone=new THREE.Mesh(
  new THREE.PlaneGeometry(2.2,2.0),
  new THREE.MeshBasicMaterial({color:0x00d9ff,transparent:true,opacity:0,side:THREE.DoubleSide})
);
analysisZone.rotation.x=-Math.PI/2;
analysisZone.position.y=3.48;
targetBuilding.add(analysisZone);

const targetBeacon=new THREE.Mesh(
  new THREE.CylinderGeometry(.045,.045,2.2,12),
  new THREE.MeshBasicMaterial({color:0x00d9ff,transparent:true,opacity:0})
);
targetBeacon.position.y=4.9;targetBuilding.add(targetBeacon);

const aiPoints = new THREE.Group();
for(let i=0;i<18;i++){
  const p = new THREE.Mesh(
    new THREE.SphereGeometry(.035,7,7),
    new THREE.MeshBasicMaterial({color:0x00d9ff,transparent:true,opacity:0})
  );
  p.position.set((Math.random()-.5)*2.1,.35+Math.random()*3.0,(Math.random()-.5)*1.9);
  aiPoints.add(p);
}
targetBuilding.add(aiPoints);
targetBuilding.position.set(5.15,0,-1.65);

const surveyGroup=new THREE.Group(); scene.add(surveyGroup);
const surveyMat=new THREE.MeshStandardMaterial({
  color:0x0d3150, metalness:.7, roughness:.3,
  emissive:0x003a62, emissiveIntensity:.85, transparent:true, opacity:.82
});
const surveyEdges=new THREE.Group(); surveyGroup.add(surveyEdges);
for(let i=0;i<12;i++){
  const w=.55+Math.random()*.75, h=1.2+Math.random()*4.2, d=.55+Math.random()*.75;
  const m=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),surveyMat);
  m.position.set(5+(Math.random()-.5)*4,h/2-.02,-1.5+(Math.random()-.5)*3.5);
  surveyGroup.add(m);
  const edge=new THREE.LineSegments(new THREE.EdgesGeometry(m.geometry),
    new THREE.LineBasicMaterial({color:0x00d9ff,transparent:true,opacity:.45}));
  edge.position.copy(m.position); surveyEdges.add(edge);
}
const surveyGrid=new THREE.Mesh(
  new THREE.PlaneGeometry(7,6,24,20),
  new THREE.MeshBasicMaterial({color:0x00d9ff,wireframe:true,transparent:true,opacity:0})
);
surveyGrid.rotation.x=-Math.PI/2; surveyGrid.position.set(5,-.02,-1.5); surveyGroup.add(surveyGrid);

const scanRing=new THREE.Mesh(
  new THREE.RingGeometry(1.2,1.27,64),
  new THREE.MeshBasicMaterial({color:0x00d9ff,transparent:true,opacity:.72,side:THREE.DoubleSide})
);
scanRing.rotation.x=-Math.PI/2;scanRing.position.y=.02;scene.add(scanRing);

const scanPulse=new THREE.Mesh(
  new THREE.RingGeometry(.35,.39,48),
  new THREE.MeshBasicMaterial({color:0xffffff,transparent:true,opacity:.55,side:THREE.DoubleSide})
);
scanPulse.rotation.x=-Math.PI/2;scanPulse.position.y=.025;scene.add(scanPulse);


// Data particles

const scanColumnGeo=new THREE.BufferGeometry().setFromPoints([
  new THREE.Vector3(0,0,0),new THREE.Vector3(0,5.5,0)
]);
const scanColumn=new THREE.Line(
  scanColumnGeo,
  new THREE.LineBasicMaterial({color:0x00d9ff,transparent:true,opacity:.28})
);
scene.add(scanColumn);



const photoPoints = new THREE.Group();
const photoPointMat = new THREE.MeshBasicMaterial({color:0x00d9ff,transparent:true,opacity:0});
for(let i=0;i<260;i++){
  const p = new THREE.Mesh(new THREE.SphereGeometry(.018,5,5),photoPointMat);
  const a=Math.random()*Math.PI*2;
  const radius=1.2+Math.random()*2.0;
  p.position.set(
    4.9 + Math.cos(a)*radius,
    .1 + Math.random()*3.8,
    -2.0 + Math.sin(a)*radius*.72
  );
  p.userData.phase=Math.random()*Math.PI*2;
  photoPoints.add(p);
}
scene.add(photoPoints);

const surfaceGeo=new THREE.PlaneGeometry(6.5,5.5,30,26);
const surfacePos=surfaceGeo.attributes.position;
for(let i=0;i<surfacePos.count;i++){
  const x=surfacePos.getX(i), z=surfacePos.getY(i);
  surfacePos.setZ(i, .12*Math.sin(x*1.7)+.08*Math.cos(z*2.1));
}
const surface=new THREE.Mesh(surfaceGeo,new THREE.MeshBasicMaterial({
  color:0x00d9ff,wireframe:true,transparent:true,opacity:0
}));
surface.rotation.x=-Math.PI/2; surface.position.set(5,.02,-1.5); scene.add(surface);
const data=new THREE.Group();scene.add(data);const dots=[];
for(let i=0;i<210;i++){const d=new THREE.Mesh(new THREE.SphereGeometry(.023,6,6),new THREE.MeshBasicMaterial({color:0x00d9ff}));d.position.set((Math.random()-.5)*18,.05+Math.random()*2.7,(Math.random()-.5)*12);d.userData.y=d.position.y;d.userData.p=Math.random()*6.28;data.add(d);dots.push(d)}

// Stage UI
const stages=[
 ["01","DRONE CAPTURE","AERIAL DATA ACQUISITION","URBAN INFRASTRUCTURE"],
 ["02","AERIAL DATA","HIGH-RESOLUTION DATA STREAM","SURVEY GRID"],
 ["03","GIS","GEOSPATIAL LAYER DETECTION","LOCATION INTELLIGENCE"],
 ["04","PHOTOGRAMMETRY","STRUCTURED AERIAL INFORMATION","3D CAPTURE ZONE"],
 ["05","3D MODEL","DIGITAL TERRAIN RECONSTRUCTION","SURFACE MODEL"],
 ["06","AI ANALYSIS","ACTIONABLE DIGITAL INSIGHTS","AI DECISION LAYER"]
];
const stageNumber=document.getElementById("stageNumber"),stageTitle=document.getElementById("stageTitle"),stageSmall=document.getElementById("stageSmall");
const hudTitle=document.getElementById("hudTitle"),hudDesc=document.getElementById("hudDesc"),targetTitle=document.getElementById("targetTitle"),targetDesc=document.getElementById("targetDesc"),progress=document.getElementById("progress"),hudBar=document.getElementById("hudBar");
const stepEls=[...document.querySelectorAll(".steps span")];
let scrollProgress=0, pointerX=0,pointerY=0,clock=0;
addEventListener("pointermove",e=>{pointerX=e.clientX/innerWidth-.5;pointerY=e.clientY/innerHeight-.5});

const hero=document.querySelector(".hero-scroll");
const STAGES=6;
let activeStage=0;
let visualProgress=0;
let sceneProgress=0;
let wheelBusy=false;
let touchStartY=null;

function setStage(stage, smooth=true){
  activeStage=Math.max(0,Math.min(STAGES-1,stage));
  const p=activeStage/(STAGES-1);
  visualProgress=p;
  scrollProgress=p;

  const start=hero.offsetTop;
  const travel=Math.max(hero.offsetHeight-innerHeight,1);
  const target=start+travel*p;

  if(smooth) window.scrollTo({top:target,behavior:"smooth"});
  else window.scrollTo({top:target,behavior:"auto"});
  updateStageUI(activeStage);
}

function updateStageUI(stage){
  document.querySelectorAll("[data-stage]").forEach(el=>{
    el.classList.toggle("active",Number(el.dataset.stage)===stage);
  });
  document.documentElement.style.setProperty("--pipeline-progress",
    (stage/(STAGES-1)).toFixed(4));
}

function heroAtStartOrEnd(){
  const start=hero.offsetTop;
  const travel=Math.max(hero.offsetHeight-innerHeight,1);
  const raw=(scrollY-start)/travel;
  return {raw,start,travel};
}

function releaseToNextSection(){
  wheelBusy=false;
  const {start,travel}=heroAtStartOrEnd();
  window.scrollTo({top:start+travel+Math.min(innerHeight*.72,520),behavior:"smooth"});
}

function releaseToPreviousSection(){
  wheelBusy=false;
  const {start}=heroAtStartOrEnd();
  window.scrollTo({top:Math.max(0,start-innerHeight*.72),behavior:"smooth"});
}

function advance(direction){
  if(wheelBusy)return;
  wheelBusy=true;

  if(direction>0){
    if(activeStage<STAGES-1){
      setStage(activeStage+1,true);
      window.setTimeout(()=>wheelBusy=false,620);
    }else{
      releaseToNextSection();
    }
  }else{
    if(activeStage>0){
      setStage(activeStage-1,true);
      window.setTimeout(()=>wheelBusy=false,620);
    }else{
      releaseToPreviousSection();
    }
  }
}

function syncStageFromScroll(){
  if(wheelBusy)return;
  const {raw}=heroAtStartOrEnd();
  if(raw<=-.02 || raw>=1.02)return;
  const stage=Math.max(0,Math.min(STAGES-1,Math.round(raw*(STAGES-1))));
  if(stage!==activeStage){
    activeStage=stage;
    visualProgress=stage/(STAGES-1);
    scrollProgress=visualProgress;
    updateStageUI(activeStage);
  }
}
addEventListener("scroll",syncStageFromScroll,{passive:true});

addEventListener("wheel",e=>{
  const rect=hero.getBoundingClientRect();
  const inside=rect.top<=innerHeight*.65 && rect.bottom>=innerHeight*.35;
  if(!inside || Math.abs(e.deltaY)<12)return;
  e.preventDefault();
  advance(e.deltaY>0?1:-1);
},{passive:false});

addEventListener("touchstart",e=>{
  if(e.touches.length===1)touchStartY=e.touches[0].clientY;
},{passive:true});

addEventListener("touchend",e=>{
  if(touchStartY===null)return;
  const y=e.changedTouches[0]?.clientY ?? touchStartY;
  const dy=touchStartY-y;
  touchStartY=null;
  const rect=hero.getBoundingClientRect();
  const inside=rect.top<=innerHeight*.75 && rect.bottom>=innerHeight*.25;
  if(!inside || Math.abs(dy)<42)return;
  advance(dy>0?1:-1);
},{passive:true});

function initHeroController(){
  activeStage=0;
  visualProgress=0;
  scrollProgress=0;
  updateStageUI(0);
  const start=hero.offsetTop;
  if((location.hash==="#home" || !location.hash) && scrollY<hero.offsetTop+innerHeight){
    window.scrollTo({top:start,behavior:"auto"});
  }
}
function ensureHeroSceneVisibility(){
  drone.visible=true;
  beam.visible=true;
  city.visible=true;
  targetBuilding.visible=true;
}
initHeroController();
ensureHeroSceneVisibility();

function updateScene(){
  const s=activeStage;
  const t=s/(STAGES-1);

  // Keep the UI/stage index discrete, but make the physical 3D scene continuous.
  // This gives the drone a real cinematic flight path between every pipeline stage.
  sceneProgress += (t-sceneProgress) * .075;
  const p=Math.max(0,Math.min(1,sceneProgress));

  // Stage progression is discrete: each visual layer turns on at its stage.
  const aerial=s>=1?1:0;
  const gis=s>=2?1:0;
  const photo=s>=3?1:0;
  const model=s>=4?1:0;
  const ai=s>=5?1:0;

  // Cinematic UAV flight path — a continuous 3D survey route around the target.
  // The aircraft moves through six deliberate positions rather than teleporting
  // between stages: approach → acquire → survey → map → reconstruct → analyze.
  const path = [
    new THREE.Vector3(7.65, 8.95, 4.55),  // 01 — approach from the perimeter
    new THREE.Vector3(6.55, 8.55, 2.95),  // 02 — acquire aerial data
    new THREE.Vector3(5.55, 8.10, 1.05),  // 03 — survey pass
    new THREE.Vector3(4.05, 7.70, -0.10), // 04 — photogrammetry sweep
    new THREE.Vector3(5.05, 8.35, -1.65), // 05 — pull back for reconstruction
    new THREE.Vector3(6.95, 9.65, -2.55)  // 06 — rise and hand off to AI
  ];
  // A continuous spline makes the aircraft feel autonomous rather than like a
  // UI element jumping between six coordinates. Closed-form easing keeps the
  // motion smooth even when the user advances a whole stage at once.
  const flightCurve = new THREE.CatmullRomCurve3(path, false, 'catmullrom', .35);
  const flight = flightCurve.getPointAt(p);
  const curveTangent = flightCurve.getTangentAt(p).normalize();
  // Gentle survey drift: a very small lateral motion and altitude breathing
  // preserve the feeling of a hovering aircraft without breaking the route.
  const lateral = new THREE.Vector3(-curveTangent.z, 0, curveTangent.x).normalize();
  flight.addScaledVector(lateral, Math.sin(clock * .55 + p * 8.0) * (.045 + .055 * (1 - p)));
  flight.y += Math.sin(clock * 1.05 + p * 6.0) * .055;
  drone.position.copy(flight);

  // Bank into the actual spline tangent. The small roll is intentionally
  // restrained so the aircraft reads as a professional survey UAV.
  const tangent = curveTangent.clone();
  const yaw = Math.atan2(tangent.x, tangent.z);
  drone.rotation.y += (yaw - drone.rotation.y) * .12;
  drone.rotation.z = THREE.MathUtils.lerp(drone.rotation.z, -tangent.x * .045, .12)
    + Math.sin(clock * 1.15 + p * 4.2) * .018;
  drone.rotation.x = Math.sin(clock * 1.35 + p * 3.1) * .018;

  // Beam is a child of the UAV, so keep it in local coordinates.
  // Its cone points straight down from the gimbal and follows the aircraft naturally.
  beam.position.set(0,-4.1,0);
  beam.rotation.set(Math.PI,0,0);
  beam.scale.x=.72+.20*aerial+.08*gis;
  beam.scale.z=.72+.20*aerial+.08*gis;
  beam.material.opacity=Math.max(.025,.12+.08*aerial+.05*gis-.12*ai);

  // Ground footprint follows the drone's projected scan position instead of staying fixed.
  const scanX = drone.position.x * .78 + targetBuilding.position.x * .22;
  const scanZ = drone.position.z * .78 + targetBuilding.position.z * .22;
  footprint.position.set(scanX, -.06, scanZ);
  footprint.material.opacity=.08+.18*aerial+.16*gis;
  footprint.scale.setScalar(.86+.20*aerial+.16*gis+.08*photo);

  scanRing.position.set(5.0,-.10,-1.5);
  scanRing.scale.setScalar(1+.28*aerial+.18*gis+.08*photo);
  scanRing.material.opacity=.30+.24*aerial+.18*gis;
  scanPulse.position.copy(scanRing.position);
  scanPulse.scale.setScalar(.75+.55*(.5+.5*Math.sin(clock*3.4)));
  scanPulse.material.opacity=.16+.26*aerial+.12*gis;

  scanColumn.position.set(scanX,-.02,scanZ);
  scanColumn.material.opacity=.05+.20*aerial+.12*gis;

  // Survey zone emerges with aerial data and becomes structured at GIS.
  surveyGroup.position.y=.01;
  surveyGroup.scale.setScalar(.92+.10*gis+.05*model);
  surveyMat.opacity=.08+.38*aerial+.28*gis;
  surveyGrid.material.opacity=.02+.24*aerial+.38*gis+.20*photo;

  // The same target structure is the visual subject throughout the pipeline.
  targetBuilding.visible=true;
  targetBuilding.position.x=4.72+.12*Math.sin(p*Math.PI*1.1);
  targetBuilding.position.z=-1.56-.08*p;
  targetSolidMat.opacity=Math.max(.08,1-photo*.88);
  targetEdges.material.opacity=.30+.35*gis;
  targetMeshMat.opacity=.02+.76*photo+.42*model;
  targetGlowMat.opacity=.03+.12*aerial+.18*gis+.28*photo+.32*model+.18*ai;
  targetGlow.scale.setScalar(1+.035*Math.sin(clock*3.5));
  targetBase.material.opacity=.02+.28*gis+.34*photo+.18*model;
  targetMarker.position.set(targetBuilding.position.x,0,targetBuilding.position.z);
  markerMat.opacity=Math.min(.92,.08+.18*aerial+.32*gis+.38*photo+.22*model+.24*ai);

  targetFrame.position.copy(targetBuilding.position);
  targetFrame.scale.setScalar(1+.035*Math.sin(clock*2.8));
  targetFrameMat.opacity=Math.min(.95,.16+.20*aerial+.30*gis+.34*photo+.24*model+.22*ai);

  targetCore.material.opacity=.18+.72*aerial;
  targetCore.scale.setScalar(1+.55*(.5+.5*Math.sin(clock*4.5)));

  // During AI analysis the aircraft rises away, leaving the reconstructed target
  // visually dominant while retaining a subtle aerial-intelligence presence.
  const analysisLift=Math.max(0,(p-.78)/.22);
  drone.position.y += analysisLift*.55;
  drone.rotation.z *= (1-analysisLift*.65);
  beam.material.opacity *= (1-analysisLift*.86);

  targetSweep.material.opacity=.02+.14*gis+.28*photo+.20*model+.16*ai;
  targetSweep.position.y=2.1+.35*Math.sin(clock*2.2);
  targetSweep.scale.x=.72+.28*(.5+.5*Math.sin(clock*3.2));

  // Photogrammetry point cloud concentrates around the target.
  photoPoints.visible=photo>0;
  photoPointMat.opacity=photo?(.18+.32*(.5+.5*Math.sin(clock*2.4))):0;
  photoPoints.position.x=targetBuilding.position.x-4.9;
  photoPoints.position.z=targetBuilding.position.z+2.0;
  photoPoints.scale.setScalar(1+.12*photo+.08*model);

  // Surface reconstruction becomes visible in stages 04–05.
  surface.visible=photo>0;
  surface.material.opacity=photo?(.16+.36*model):0;
  surface.position.set(targetBuilding.position.x,.02,targetBuilding.position.z);
  surface.scale.setScalar(1+.12*model);

  // AI detection layer is reserved for stage 06.
  aiFrameMat.opacity=ai?.86:0;
  detectionLineMat.opacity=ai*(.28+.58*(.5+.5*Math.sin(clock*5)));
  analysisZone.material.opacity=ai*(.08+.18*(.5+.5*Math.sin(clock*4.8)));
  analysisZone.scale.setScalar(.96+ai*.12);
  targetBeacon.material.opacity=ai?.78:0;
  targetBeacon.scale.y=.75+ai*(.55+.35*Math.sin(clock*4.2));

  aiPoints.children.forEach((p,i)=>{
    p.material.opacity=ai*(.28+.55*(.5+.5*Math.sin(clock*3+i*.35)));
    p.scale.setScalar(.8+ai*(.5+.5*Math.sin(clock*3+i)));
  });

  // Ambient data particles grow more active as information moves through the pipeline.
  dots.forEach((d,i)=>{
    d.material.opacity=.16+.16*aerial+.10*gis+.08*photo;
    d.scale.setScalar(1+model*.35+ai*.25);
  });

  // HUD text and progress.
  const targetLockLabel=document.getElementById("targetLockLabel");
  if(targetLockLabel) targetLockLabel.style.opacity=s>=1?.88:0;
  if(targetLockLabel) {
    // Keep the target-lock callout attached to the 3D target instead of a fixed
    // screen coordinate. This makes the HUD feel like a real tracking interface.
    const projected = targetBuilding.position.clone();
    projected.y += 4.15;
    projected.project(camera);
    const px = THREE.MathUtils.clamp((projected.x * .5 + .5) * 100, 34, 72);
    const py = THREE.MathUtils.clamp((-projected.y * .5 + .5) * 100, 30, 67);
    targetLockLabel.style.left = px + "%";
    targetLockLabel.style.top = py + "%";
  }

  const data=stages[s];
  if(stageNumber) stageNumber.textContent=data[0];
  if(stageTitle) stageTitle.textContent=data[1];
  if(stageSmall) stageSmall.textContent=data[2];
  if(hudTitle) hudTitle.textContent=data[1];
  if(hudDesc) hudDesc.textContent=data[2];
  if(targetTitle) targetTitle.textContent=data[3];
  if(targetDesc) targetDesc.textContent=s>=5?"AI DETECTION / DECISION LAYER":
    s>=4?"SURFACE MODEL / 3D RECONSTRUCTION":
    s>=3?"POINT CLOUD / 3D CAPTURE":
    s>=2?"GEOSPATIAL LAYER / LOCATION INTELLIGENCE":
    s>=1?"AERIAL DATA / SURVEY GRID":"GRID ANALYSIS / 3D CAPTURE";
  if(altitude) altitude.textContent=(182-Math.round(t*18))+" M";
  if(hudBar) hudBar.style.width=(18+s*15)+"%";
  if(progress) progress.style.width=(s/(STAGES-1)*100)+"%";
  stepEls.forEach((el,i)=>el.classList.toggle("active",i===s));

  // More camera emphasis on the target from GIS onward.
  const focusBlend=Math.max(0,Math.min(1,(s-2)/3));
  const focusX=targetBuilding.position.x*(.08+.26*focusBlend);
  const focusY=3.05+.82*focusBlend;
  camera.lookAt(focusX,focusY,0);
}

function animate(){
  ensureHeroSceneVisibility();
  requestAnimationFrame(animate);clock+=.016;
  dots.forEach(d=>d.position.y=d.userData.y+Math.sin(clock*2.2+d.userData.p)*.06);
  const targetX=pointerX*1.25 + (drone.position.x*.022),targetY=7.9-pointerY*.72;
  camera.position.x+=(targetX-camera.position.x)*.018;
  camera.position.y+=(targetY-camera.position.y)*.018;
  const targetZ=27-Math.sin(sceneProgress*Math.PI)*6.2;
  camera.position.z+=(targetZ-camera.position.z)*.025;
  const focusBlend=Math.max(0,Math.min(1,(sceneProgress-.30)/.48));
  const focusX=targetBuilding.position.x*(.04+.13*focusBlend);
  const focusY=3.0+.65*focusBlend;
  camera.lookAt(focusX,focusY,0);
  updateScene();
  renderer.render(scene,camera);
}
animate();

addEventListener("resize",()=>{camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight)});
