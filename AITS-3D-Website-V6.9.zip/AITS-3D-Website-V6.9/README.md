# AITS – Afaq Innovations for Technology Solutions

V6.9 — Hero collision and cinematic aerial-motion refinement.

## Run
1. Open this folder in VS Code.
2. Right-click `index.html`.
3. Choose **Open with Live Server**.

No Python is required.

## V6.9 changes
- Desktop hero metrics moved to a dedicated bottom-right zone to eliminate overlap with CTA buttons.
- Metrics are hidden on small screens for a cleaner responsive layout.
- V6.8 cinematic drone route, scan beam, target lock and six-stage pipeline are preserved.
